
//箭头函数

var fun = (value)=>{
  value *= 10;
  return value;
};
console.log(fun(10));


var fun2 = (value)=> value * 10;
console.log(fun2(10));
