
## cookie session

```
cookie: 存储在浏览器端，存储量非常小，大概是4096B,存储非常重要的信息，用于和服务端进行状态的确认
session: 存储在浏览器端，存储量非常大，用于保存客户端的身份或者登录信息.
session 依赖于客户端的cookie， 产生的sessionID需要以cookie的方式存储在客户端上
```
