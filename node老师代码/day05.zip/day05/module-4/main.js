
var obj = require('./add.js');

console.log(obj);
/*
{
  count: 2,
  add: function(){}
}
*/

obj.add();
obj.add();
obj.add();
obj.add();
obj.add();
obj.add();
obj.add();
obj.add();
obj.add();
obj.add();

console.log(obj.count);
