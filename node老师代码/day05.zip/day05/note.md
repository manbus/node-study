
##commonJS 规范

* 什么是commonJS
* 特点 : 随时导入，就近导入


### require导入
*  同一个模块只需导入一次即可，重复导入没有意义(从内存中读取)
*  注意循环导入的问题

### socket.io 
