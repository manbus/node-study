
var os = require('os');

//cpu的核心数量
console.log(os.cpus().length);
console.log(os.platform());
