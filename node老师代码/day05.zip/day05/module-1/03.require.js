
var temp = require('./01.module.js');
console.log(temp);
