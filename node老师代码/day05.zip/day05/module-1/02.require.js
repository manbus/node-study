

//require是导入了 01.module.js中导出的对象
var obj = require('./01.module.js');
console.log(obj.add(10,20));
console.log(obj.minus(20,10));
