
## redis 密码
```
windows: redis.windows.conf
linux:  redis.conf  

requirepass 密码


连接指定密码：  redis-cli  -a  密码


expire key seconds  指定让一个key过期删除

```
