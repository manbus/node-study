#nvm nodejs多版本管理工具

```
nvm ls  列出当前系统上安装的nodejs版本
nvm current 列出当前的nodejs版本
nvm ls-remote  列出nodejs的所有版本
nvm use xxx   使用指定的nodejs版本

nvm install xxx  安装指定的版本
nvm uninstall xxx  写在指定的版本

```


# nodejs
*  nodejs 的体系架构
*  nodejs 的事件循环机制 http://www.ruanyifeng.com/blog/2014/10/event-loop.html
