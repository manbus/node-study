
//pipe 管道， 直接将输入流中的数据输出到输出流中
process.stdin.pipe(process.stdout);


/*
1. 自学 es6 箭头函数 ()=>{}
*/
