
console.log("%c脚本执行", "font-size: 30px; color:green;");
