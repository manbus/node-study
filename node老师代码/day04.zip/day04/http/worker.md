
## 作业 要求

1. html页面发送一个ajax请求，请求10行表格数据，添加到dom中
2. server 读取本地的一个student.json文件， 将json文件中的前10个数据发个html页面
